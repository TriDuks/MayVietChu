/* eslint-env node */
'use strict';

module.exports = {
  arrowParens: 'always',
  printWidth: 100,
  singleQuote: true,
  trailingComma: 'all',
};
