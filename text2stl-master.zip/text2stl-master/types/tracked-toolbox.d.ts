declare module 'tracked-toolbox' {
  export let cached: PropertyDecorator;
}
